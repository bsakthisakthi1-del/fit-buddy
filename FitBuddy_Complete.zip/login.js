
const USER="fitbuddyUser",PROFILE="fitbuddyProfile";
let mode="login";
function toast(m){const t=document.getElementById("toast");t.textContent=m;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}
function showMode(m){
 mode=m;document.getElementById("loginTab").classList.toggle("active",m==="login");document.getElementById("signupTab").classList.toggle("active",m==="signup");
 document.getElementById("nameGroup").style.display=m==="signup"?"block":"none";
 document.getElementById("formTitle").textContent=m==="signup"?"Create your account":"Welcome back";
 document.getElementById("formText").textContent=m==="signup"?"Start building healthier everyday habits.":"Continue your wellness journey.";
 document.getElementById("submitBtn").textContent=m==="signup"?"Create account":"Login";
}
document.getElementById("authForm").addEventListener("submit",e=>{
 e.preventDefault();const email=document.getElementById("authEmail").value.trim().toLowerCase(),password=document.getElementById("authPassword").value;
 const name=document.getElementById("authName").value.trim();
 if(mode==="signup"){
   if(!name)return toast("Enter your name");
   const user={name,email,password};localStorage.setItem(USER,JSON.stringify(user));localStorage.setItem(PROFILE,JSON.stringify({name,email,age:"",goal:"General wellness"}));location.href="index.html";
 }else{
   const old=JSON.parse(localStorage.getItem(USER)||"null");
   if(!old)return toast("No account found. Please sign up first.");
   if(old.email!==email||old.password!==password)return toast("Email or password is incorrect");
   localStorage.setItem(USER,JSON.stringify({...old}));location.href="index.html";
 }
});
