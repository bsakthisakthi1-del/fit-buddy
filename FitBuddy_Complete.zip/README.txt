# FitBuddy
A beginner-friendly, mobile-first women's wellness and lifestyle website.

## Run in Acode
1. Create/open the FitBuddy folder.
2. Put all files in the same folder.
3. Open `login.html` in preview/browser.
4. Sign up.
5. The website stores demo account/profile and wellness data in LocalStorage.

## Pages
Login, Home, Fitness, Food & Meals, Water, Sleep, Activity, Wellness, Progress, Profile.

## Technologies
HTML5, CSS3, JavaScript, LocalStorage.

No AI assistant, no PWA, no backend required.
