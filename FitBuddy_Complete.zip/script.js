
const FB = {
 userKey:"fitbuddyUser", profileKey:"fitbuddyProfile", waterKey:"fitbuddyWater",
 sleepKey:"fitbuddySleep", stepsKey:"fitbuddySteps", moodKey:"fitbuddyWellness",
 workoutsKey:"fitbuddyWorkouts", habitsKey:"fitbuddyHabits", mealsKey:"fitbuddyMeals"
};
function get(k,d=null){try{return JSON.parse(localStorage.getItem(k)) ?? d}catch(e){return d}}
function set(k,v){localStorage.setItem(k,JSON.stringify(v))}
function toast(msg){const t=document.getElementById("toast");if(!t)return;t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}
function requireLogin(){if(!get(FB.userKey)) location.href="login.html"}
function today(){return new Date().toISOString().slice(0,10)}
function ensureDaily(key,defaultValue){let x=get(key);if(!x||x.date!==today()){x={date:today(),value:defaultValue};set(key,x)}return x}
function score(){
 const w=ensureDaily(FB.waterKey,0).value,s=ensureDaily(FB.sleepKey,0).value,a=ensureDaily(FB.stepsKey,0).value,m=get(FB.moodKey);
 const habits=get(FB.habitsKey,{date:today(),items:{}});let h=habits.date===today()?Object.values(habits.items).filter(Boolean).length:0;
 return Math.min(100,Math.round((Math.min(w,8)/8*25)+(Math.min(s,8)/8*20)+(Math.min(a,6000)/6000*20)+(m?.date===today()?15:0)+(h/5*20)));
}
function setupNav(){
 const page=location.pathname.split("/").pop()||"index.html";
 const map={index:"home",fitness:"fitness",food:"food",wellness:"wellness",profile:"profile"};
 const key=map[page.replace(".html","")];
 document.querySelectorAll("[data-nav]").forEach(a=>{if(a.dataset.nav===key)a.classList.add("active")})
}
function homeInit(){
 requireLogin();const p=get(FB.profileKey,{}),u=get(FB.userKey,{});
 const name=p.name||u.name||"there"; document.getElementById("homeName").textContent=name.split(" ")[0];
 const w=ensureDaily(FB.waterKey,0).value,s=ensureDaily(FB.sleepKey,0).value,a=ensureDaily(FB.stepsKey,0).value,m=get(FB.moodKey);
 document.getElementById("waterStat").textContent=w+" / 8";document.getElementById("sleepStat").textContent=s+"h";document.getElementById("stepsStat").textContent=a;document.getElementById("moodStat").textContent=m?.date===today()?m.mood:"—";
 const sc=score();document.getElementById("score").textContent=sc+"%";document.getElementById("scoreBar").style.width=sc+"%";
 const h=get(FB.habitsKey,{date:today(),items:{}});document.querySelectorAll(".habit").forEach(c=>{c.checked=h.date===today()&&!!h.items[c.dataset.id];c.onchange=saveHabits});updateHabitCount();
}
function saveHabits(){const items={};document.querySelectorAll(".habit").forEach(c=>items[c.dataset.id]=c.checked);set(FB.habitsKey,{date:today(),items});updateHabitCount();const sc=score();document.getElementById("score").textContent=sc+"%";document.getElementById("scoreBar").style.width=sc+"%";toast("Habit updated")}
function updateHabitCount(){const c=document.querySelectorAll(".habit:checked").length;const el=document.getElementById("habitCount");if(el)el.textContent=c+" / 5"}
function completeWorkout(name){let x=get(FB.workoutsKey,[]);x.push({date:today(),name});set(FB.workoutsKey,x);const el=document.getElementById("workoutCount");if(el)el.textContent=x.length;toast(name+" completed")}
function fitnessInit(){requireLogin();const x=get(FB.workoutsKey,[]);const el=document.getElementById("workoutCount");if(el)el.textContent=x.length}
function editMeal(type){const value=prompt("What did you have for "+type+"?");if(value===null)return;const meals=get(FB.mealsKey,{});meals[today()]={...(meals[today()]||{}),[type]:value};set(FB.mealsKey,meals);foodInit();toast("Meal saved")}
function foodInit(){requireLogin();const m=get(FB.mealsKey,{})[today()]||{};["breakfast","lunch","dinner","snack"].forEach(x=>{const e=document.getElementById("meal"+x[0].toUpperCase()+x.slice(1));if(e)e.textContent=m[x]||"Not added"})}
function changeWater(delta){let x=ensureDaily(FB.waterKey,0);x.value=Math.max(0,Math.min(20,x.value+delta));set(FB.waterKey,x);waterInit();toast(delta>0?"Water added":"Water removed")}
function waterInit(){requireLogin();const x=ensureDaily(FB.waterKey,0).value;document.getElementById("waterBig").textContent=x+" / 8";document.getElementById("waterBar").style.width=Math.min(100,x/8*100)+"%"}
function saveSleep(){const v=parseFloat(document.getElementById("sleepInput").value);if(isNaN(v)||v<0||v>24)return toast("Enter a valid sleep duration");set(FB.sleepKey,{date:today(),value:v});toast("Sleep saved")}
function sleepInit(){requireLogin();const x=ensureDaily(FB.sleepKey,0).value;if(x)document.getElementById("sleepInput").value=x}
function saveSteps(){const v=parseInt(document.getElementById("stepsInput").value);if(isNaN(v)||v<0)return toast("Enter valid steps");set(FB.stepsKey,{date:today(),value:v});activityInit();toast("Activity saved")}
function activityInit(){requireLogin();const x=ensureDaily(FB.stepsKey,0).value;document.getElementById("activitySteps").textContent=x;document.getElementById("stepsInput").value=x||""}
let selectedMood="";
function setMood(m,b){selectedMood=m;document.querySelectorAll("#moodChoices button").forEach(x=>x.classList.remove("selected"));b.classList.add("selected")}
function saveWellness(){if(!selectedMood){const old=get(FB.moodKey);selectedMood=old?.mood||""}if(!selectedMood)return toast("Choose a mood first");set(FB.moodKey,{date:today(),mood:selectedMood,reflection:document.getElementById("reflection").value});toast("Wellness check-in saved")}
function wellnessInit(){requireLogin();const x=get(FB.moodKey);if(x?.date===today()){selectedMood=x.mood;document.getElementById("reflection").value=x.reflection||"";document.querySelectorAll("#moodChoices button").forEach(b=>{if(b.textContent.includes(x.mood))b.classList.add("selected")})}}
function progressInit(){requireLogin();const w=get(FB.workoutsKey,[]).length,wa=ensureDaily(FB.waterKey,0).value,s=ensureDaily(FB.stepsKey,0).value,sl=ensureDaily(FB.sleepKey,0).value,sc=score();document.getElementById("pWorkouts").textContent=w;document.getElementById("pWater").textContent=wa;document.getElementById("pSteps").textContent=s;document.getElementById("pSleep").textContent=sl+"h";document.getElementById("pScore").textContent=sc+"%";document.getElementById("pBar").style.width=sc+"%"}
function saveProfile(){const p={name:document.getElementById("profileName").value.trim(),email:document.getElementById("profileEmail").value.trim(),age:document.getElementById("profileAge").value,goal:document.getElementById("profileGoal").value};if(!p.name)return toast("Please enter your name");set(FB.profileKey,p);const u=get(FB.userKey,{});set(FB.userKey,{...u,name:p.name,email:p.email});toast("Profile saved")}
function profileInit(){requireLogin();const u=get(FB.userKey,{}),p=get(FB.profileKey,{});document.getElementById("profileName").value=p.name||u.name||"";document.getElementById("profileEmail").value=p.email||u.email||"";document.getElementById("profileAge").value=p.age||"";document.getElementById("profileGoal").value=p.goal||"General wellness"}
function logout(){localStorage.removeItem(FB.userKey);location.href="login.html"}
document.addEventListener("DOMContentLoaded",()=>{setupNav();const page=location.pathname.split("/").pop()||"index.html";const fn={ "index.html":homeInit,"fitness.html":fitnessInit,"food.html":foodInit,"water.html":waterInit,"sleep.html":sleepInit,"activity.html":activityInit,"wellness.html":wellnessInit,"progress.html":progressInit,"profile.html":profileInit}[page];if(fn)fn()});
